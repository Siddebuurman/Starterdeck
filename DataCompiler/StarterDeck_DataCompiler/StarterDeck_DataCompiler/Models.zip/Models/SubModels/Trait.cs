﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarterDeck_DataCompiler.Models.SubModels
{
    public class Trait
    {
        public string name;
        public string boundCategory;
    }
}
